class PerangkatElektronik {
    String nama;

    public PerangkatElektronik(String nama) {
        this.nama = nama;
    }

    public String fungsi() {
        return "Fungsi tidak diketahui";
    }
}